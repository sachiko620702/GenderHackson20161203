//
//  ViewController.h
//  browser
//
//  Created by Sapp on 12/8/16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *myWebView;

@end
